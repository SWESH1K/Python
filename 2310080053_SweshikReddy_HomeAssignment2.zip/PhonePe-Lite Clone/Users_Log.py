users = {
    "Sweshik": {
        "password": "password1",
        "pin": 1234,
        "balance": 51114
    },
    "Lucky": {
        "password": "password2",
        "pin": 4321,
        "balance": 75224
    },
    "Zaid": {
        "password": "password3",
        "pin": 5678,
        "balance": 47645
    }
}